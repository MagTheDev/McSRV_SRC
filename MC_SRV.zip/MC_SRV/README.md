
!!!TO RUN THIS CODE YOU MUST HAVE PYTHON 3.8.5!!!
link: https://www.python.org/downloads/


This is a program that lets ou install and run Minecraft server. I do NOT own any right to Minecraf or Spigot MC, this is just a fan-made code to help everybody out.
If you get error: Cant acess {xyz}, then download new version of this file. 