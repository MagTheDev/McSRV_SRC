import os
import shutil
import jdk,
from urllib.request import urlretrieve



def FetchBuildTools():
    if os.path.exists("BuildTools.jar"):
        print("Build tools downloaded, not downloading.")
        return

    try:
        url = "https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar"
        print("Downloading build tools...")
        urlretrieve(url, "BuildTools.jar")
    except Exception as e:
        print("Error while downloading build tools: %s" % (str(e)))


def EditEula():
    if not os.path.exists("eula.txt"):
        return
    f = open("eula.txt", "r")
    data = f.read()
    f.close()
    data = data.replace("false", "true")
    f = open("eula.txt", "w+")
    f.write(data)
    f.close()




def InstallJava(ver):
    try:
        print(f"Installing Java Runtime Environment 8")
        jdk.install(ver, jre=True)
        print("Done")
    except StopIteration:
        pass

def UninstallJava(ver):
    try:
        print(f"Uninstalling Java Runtime Environment 8")
        jdk.uninstall(ver, jre=True)
        print("Done")
    except StopIteration:
        pass


def InstallServer():

    curr_dir = os.getcwd()
    print("Do you want to install in current directory? (y/n)")
    print(f"{curr_dir} - is your current directory")
    install_in_curr_dir = input()

    if install_in_curr_dir == "y":
        print("Installing...")
        os.chdir(f"{os.getcwd()}")
        os.system(f"java -jar BuildTools.jar --rev latest")
        print("Installing stopped...")
        Menu()



    elif install_in_curr_dir == "n":

        user_dir = input("Your Directory: ")
        os.chdir(user_dir)
        print("Installing...")
        os.system(f"java -jar BuildTools.jar --rev latest")
        Menu()

pass



def UpdateServer():

    print("Updating")
    os.system(f"java -jar BuildTools.jar --rev latest")
    Menu()
pass


def DeleteServer():

    print("Where are your server files located? (type the whole path to directory)")
    dir_for_data = input()
    print(f"Are you sure you want do delete your whole server? This action can't be undone (y/n)")
    dele = input()
    if dele == "y":
        shutil.rmtree(dir_for_data, ignore_errors = True, onerror = None)
        Menu()
    else:
        "Error occurred during deleting files..."
        Menu()

def RunServer():

    print("Run server?  (y/n)")
    run = input()

    if run == "y":
        os.system(f'java -Xmx3G -jar spigot-1.16.3.jar -nogui')
        Menu()
    else:
        print("Wrong input, going back to menu...")
        Menu()
    Menu()

def Menu():

    print(" What do you want to do?")
    print(" ")
    print(" ")
    print("[0] -- Install server")
    print("[1] -- Run Server")
    print("[2] -- Update Server")
    print("[3] -- DELETE SERVER")

    choice = input()

    if choice == "0":
        InstallJava(8)
        FetchBuildTools()
        InstallServer()

    elif choice == "1":
        EditEula()
        RunServer()
    elif choice == "2":
        UpdateServer()
    elif choice == "3":
        UninstallJava(8)
        DeleteServer()
    pass

Menu()